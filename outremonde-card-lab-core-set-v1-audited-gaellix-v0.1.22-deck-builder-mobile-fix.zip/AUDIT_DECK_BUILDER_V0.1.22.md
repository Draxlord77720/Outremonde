# Audit Deck Builder V0.1.22

Hotfix ciblé sur l'interaction et le rendu mobile du Deck Builder.

- Les contrôles d'ajout/retrait ne partagent plus le bouton de consultation de la carte.
- Une carte absente du deck présente un bouton d'ajout dédié ; après ajout, le contrôle devient − / quantité / +.
- La vue mobile sépare la collection et le deck actif via deux onglets pour éviter les colonnes écrasées.
- Les listes mobiles utilisent le scroll de la page, sans zone interne de 470 px.
- Les limites restent : 40 cartes exactement, 3 exemplaires maximum par carte.
- Gaellix reste légale en 3 exemplaires et compte normalement dans les 40 cartes.
- Données de cartes et règles non modifiées.
